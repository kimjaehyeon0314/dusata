from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum
from datetime import datetime, timedelta


class GenderEnum(str, Enum):
    male = "male"
    female = "female"


class HobbyEnum(str, Enum):
    reading = "독서"
    cooking = "요리"
    exercise = "운동"
    travel = "여행"
    photography = "사진 찍기"
    music = "음악 감상"
    movies = "영화 감상"
    drawing = "그림 그리기"
    dance = "댄스"
    hiking = "등산"
    swimming = "수영"
    yoga = "요가"
    art = "미술"
    gaming = "게임"
    fishing = "낚시"


class MbtiEnum(str, Enum):
    ISTJ = "ISTJ"
    ISFJ = "ISFJ"
    INFJ = "INFJ"
    INTJ = "INTJ"
    ISTP = "ISTP"
    ISFP = "ISFP"
    INFP = "INFP"
    INTP = "INTP"
    ESTP = "ESTP"
    ESFP = "ESFP"
    ENFP = "ENFP"
    ENTP = "ENTP"
    ESTJ = "ESTJ"
    ESFJ = "ESFJ"
    ENFJ = "ENFJ"
    ENTJ = "ENTJ"


class AnimalEnum(str, Enum):
    dog = "강아지상"
    cat = "고양이상"
    bear = "곰상"
    fox = "여우상"
    rabbit = "토끼상"
    deer = "사슴상"
    tiger = "호랑이상"
    hedgehog = "고슴도치상"


class UserBase(BaseModel):
    phone_number: str
    user_name: str
    user_kakao: str
    major: str
    student_number: int
    gender: GenderEnum
    hobby: HobbyEnum
    mbti: MbtiEnum
    smoke: bool
    animal: AnimalEnum
    introduce: str


class UserCreate(UserBase):
    pass


class User(UserBase):
    id: int

    class Config:
        orm_mode = True


# 공통 속성을 정의하는 베이스 모델
class AuthPhoneBase(BaseModel):
    phone_number: str
    verification_code: str
    verified: bool = False


# 생성 시 사용할 모델
class AuthPhoneCreate(AuthPhoneBase):
    user_id: int
    expires_at: datetime = Field(
        default_factory=lambda: datetime.utcnow() + timedelta(minutes=10)
    )


# 응답 시 사용할 모델
class AuthPhoneResponse(BaseModel):
    success: bool


class PhoneNumberRequest(BaseModel):
    phone_number: str


class PhoneAuthCheckRequest(BaseModel):
    phone_number: str
    verification_code: str


class VerificationResponse(BaseModel):
    verification_success: bool
    is_registered: bool
    auth_token: str
    redirect: str


class UserResponse(UserBase):
    id: int

    class Config:
        orm_mode = True
